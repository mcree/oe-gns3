iousniffer
==========

A tool which intercepts traffic on IOU netio sockets and writes it to pcap files
